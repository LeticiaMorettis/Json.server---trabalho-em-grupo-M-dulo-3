# Formulários



Onde se encontram o Input(inserção de dados pelo usuário);

- O Input.js será utilizado na página imóveis. Inserir os inputs de registrar endereço. Se possível, colocar o API de CEP para fazer o preenchimento automático
- Criar mais dois formulários(InputVend.js e InputClient.js) para a inserção de novos vendedores o compradores.
- 
