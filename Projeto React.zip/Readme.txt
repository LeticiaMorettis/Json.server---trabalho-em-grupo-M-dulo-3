Projeto Cine Star:

Cinema administrador.

Site administrador utilizando o json.server

O site deve realiza todos os métodos 
HTTP:
□ GET 
□ POST 
□ PUT 
□ DELETE 

--------------------------------- Projeto em Grupo do Modulo 3 ------------------------------------

